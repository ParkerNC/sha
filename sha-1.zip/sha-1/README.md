#sha-1
##parker collier

to compile and run the code, enter this command on a linux terminal: 

> make go

to only compile the code:

> make

after compilation the executable can be ran with:

> ./sha
